from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
)

from PyQt6.QtCore import Qt

from desktop_ui.widgets.sidebar import Sidebar
from desktop_ui.widgets.info_card import InfoCard
from desktop_ui.widgets.upload_card import UploadCard
from desktop_ui.widgets.scan_card import ScanCard
from desktop_ui.widgets.logs_widget import LogsWidget
from desktop_ui.widgets.activity_widget import ActivityWidget
from desktop_ui.widgets.progress_card import ProgressCard

from desktop_ui.components.top_bar import TopBar
from desktop_ui.components.system_info import SystemInfo
from desktop_ui.components.circular_gauge import CircularGauge


class MainWindow(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "NeuroFence Enterprise AI Security Platform"
        )

        self.resize(1500,900)

        self.setup_ui()

    ###################################################

    def setup_ui(self):

        central_widget = QWidget()

        self.setCentralWidget(central_widget)

        root_layout = QHBoxLayout()

        root_layout.setContentsMargins(0, 0, 0, 0)

        root_layout.setSpacing(0)

        central_widget.setLayout(root_layout)

        ###################################################
        # Sidebar
        ###################################################

        self.sidebar = Sidebar()

        root_layout.addWidget(self.sidebar)

        ###################################################
        # Right Side
        ###################################################

        right_widget = QWidget()

        right_layout = QVBoxLayout()

        right_layout.setContentsMargins(20, 20, 20, 20)

        right_layout.setSpacing(20)

        right_widget.setLayout(right_layout)

        root_layout.addWidget(right_widget)

        ###################################################
        # Professional Top Bar
        ###################################################

        self.top_bar = TopBar()

        right_layout.addWidget(self.top_bar)

        ###################################################
        # Statistics Cards
        ###################################################

        stats_layout = QGridLayout()

        stats_layout.setHorizontalSpacing(20)

        stats_layout.setVerticalSpacing(20)

        self.card_models = InfoCard(
            "Models Loaded",
            "0"
        )

        self.card_threat = InfoCard(
            "Threat Score",
            "0%"
        )

        self.card_status = InfoCard(
            "System Status",
            "Ready"
        )

        stats_layout.addWidget(
            self.card_models,
            0,
            0
        )

        stats_layout.addWidget(
            self.card_threat,
            0,
            1
        )

        stats_layout.addWidget(
            self.card_status,
            0,
            2
        )

        right_layout.addLayout(stats_layout)

        ###################################################
        # Upload + Scan
        ###################################################

        middle_layout = QHBoxLayout()

        middle_layout.setSpacing(20)

        self.upload_card = UploadCard()

        self.scan_card = ScanCard()

        middle_layout.addWidget(self.upload_card)

        middle_layout.addWidget(self.scan_card)

        right_layout.addLayout(middle_layout)

        ###################################################
        # Threat Analysis
        ###################################################

        analysis_layout = QHBoxLayout()

        analysis_layout.setSpacing(20)

        self.gauge = CircularGauge()

        self.system_info = SystemInfo()

        analysis_layout.addWidget(
            self.gauge,
            1
        )

        analysis_layout.addWidget(
            self.system_info,
            1
        )

        right_layout.addLayout(analysis_layout)

        ###################################################
        # Activity + Progress
        ###################################################

        bottom_layout = QHBoxLayout()

        bottom_layout.setSpacing(20)

        self.activity = ActivityWidget()

        self.progress_card = ProgressCard()

        bottom_layout.addWidget(
            self.activity,
            2
        )

        bottom_layout.addWidget(
            self.progress_card,
            1
        )

        right_layout.addLayout(bottom_layout)

        ###################################################
        # Live Logs
        ###################################################

        self.logs_widget = LogsWidget()

        right_layout.addWidget(
            self.logs_widget
        )

        ###################################################
        # Stretch
        ###################################################

        right_layout.addStretch()

        ###################################################
        # Status Bar
        ###################################################

        self.statusBar().showMessage(
            "✔ Ready | NeuroFence Enterprise v1.0 | AI Security Platform"
        )

        ###################################################
        # Menu Bar
        ###################################################

        file_menu = self.menuBar().addMenu("File")

        tools_menu = self.menuBar().addMenu("Tools")

        help_menu = self.menuBar().addMenu("Help")

        exit_action = file_menu.addAction("Exit")

        about_action = help_menu.addAction("About NeuroFence")

        exit_action.triggered.connect(self.close)

        about_action.triggered.connect(self.show_about)

        ###################################################
        # Button Connections
        ###################################################

        self.scan_card.scan_button.clicked.connect(
            self.start_scan
        )

    ###################################################
    # Scan Demo
    ###################################################

    def start_scan(self):

        ###################################################
        # Reset
        ###################################################

        self.logs_widget.logs.clear()

        self.activity.list.clear()

        self.progress_card.progress.setValue(0)

        self.gauge.setValue(5)

        self.statusBar().showMessage(
            "Initializing Security Scan..."
        )

        ###################################################
        # Step 1
        ###################################################

        self.activity.add_activity(
            "Security scan started"
        )

        self.logs_widget.add_log(
            "Initializing NeuroFence..."
        )

        self.progress_card.progress.setValue(10)

        self.gauge.setValue(10)

        ###################################################
        # Step 2
        ###################################################

        self.activity.add_activity(
            "Checking model structure"
        )

        self.logs_widget.add_log(
            "Checking model architecture..."
        )

        self.progress_card.progress.setValue(25)

        self.gauge.setValue(18)

        ###################################################
        # Step 3
        ###################################################

        self.activity.add_activity(
            "Loading model weights"
        )

        self.logs_widget.add_log(
            "Loading model weights..."
        )

        self.progress_card.progress.setValue(40)

        self.gauge.setValue(30)

        ###################################################
        # Step 4
        ###################################################

        self.activity.add_activity(
            "Searching dormant neurons"
        )

        self.logs_widget.add_log(
            "Scanning hidden neuron activations..."
        )

        self.progress_card.progress.setValue(60)

        self.gauge.setValue(45)

        ###################################################
        # Step 5
        ###################################################

        self.activity.add_activity(
            "Running adversarial prompts"
        )

        self.logs_widget.add_log(
            "Executing prompt fuzzing..."
        )

        self.progress_card.progress.setValue(80)

        self.gauge.setValue(65)

        ###################################################
        # Step 6
        ###################################################

        self.activity.add_activity(
            "Generating security report"
        )

        self.logs_widget.add_log(
            "Generating analysis report..."
        )

        self.progress_card.progress.setValue(95)

        self.gauge.setValue(18)

        ###################################################
        # Finish
        ###################################################

        self.activity.add_activity(
            "Scan completed successfully"
        )

        self.logs_widget.add_log(
            "No weight poisoning detected."
        )

        self.logs_widget.add_log(
            "No dormant backdoor trigger found."
        )

        self.logs_widget.add_log(
            "Threat Score : 18%"
        )

        self.logs_widget.add_log(
            "Model Status : SAFE"
        )

        self.progress_card.progress.setValue(100)

        self.gauge.setValue(18)

        self.statusBar().showMessage(
            "✔ Scan Completed Successfully"
        )

        self.scan_card.status.setText(
            "Status : Protected"
        )

        ###################################################
        # Update Dashboard Cards
        ###################################################

        try:

            self.card_models.set_value("1")

            self.card_threat.set_value("18%")

            self.card_status.set_value("Protected")

        except AttributeError:

            pass

    ###################################################
    # About
    ###################################################

    def show_about(self):

        self.logs_widget.add_log("")

        self.logs_widget.add_log("=" * 45)

        self.logs_widget.add_log("NeuroFence v1.0")

        self.logs_widget.add_log(
            "Enterprise AI Security Platform"
        )

        self.logs_widget.add_log(
            "LLM Weight Poisoning & Backdoor Scanner"
        )

        self.logs_widget.add_log(
            "Developed using PyQt6"
        )

        self.logs_widget.add_log("=" * 45)