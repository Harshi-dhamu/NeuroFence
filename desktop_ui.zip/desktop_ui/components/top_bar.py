from PyQt6.QtWidgets import (
    QWidget,
    QLabel,
    QHBoxLayout,
    QVBoxLayout,
    QFrame,
)

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont

from datetime import datetime


class TopBar(QFrame):

    def __init__(self):
        super().__init__()

        self.setObjectName("TopBar")

        self.setFixedHeight(90)

        self.setup_ui()

        self.start_clock()

    ##########################################################

    def setup_ui(self):

        layout = QHBoxLayout()

        layout.setContentsMargins(20, 10, 20, 10)

        self.setLayout(layout)

        ##################################################
        # Left
        ##################################################

        left = QVBoxLayout()

        title = QLabel("NeuroFence")

        title.setFont(QFont("Segoe UI", 22, QFont.Weight.Bold))

        title.setStyleSheet("""
            color:#58A6FF;
        """)

        subtitle = QLabel(
            "Enterprise AI Security Platform"
        )

        subtitle.setStyleSheet("""
            color:#8B949E;
            font-size:12px;
        """)

        left.addWidget(title)

        left.addWidget(subtitle)

        layout.addLayout(left)

        layout.addStretch()

        ##################################################
        # Center
        ##################################################

        center = QVBoxLayout()

        self.time_label = QLabel()

        self.time_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.time_label.setStyleSheet("""
            font-size:20px;
            font-weight:bold;
            color:white;
        """)

        self.date_label = QLabel()

        self.date_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.date_label.setStyleSheet("""
            color:#8B949E;
            font-size:11px;
        """)

        center.addWidget(self.time_label)

        center.addWidget(self.date_label)

        layout.addLayout(center)

        layout.addStretch()

        ##################################################
        # Right
        ##################################################

        right = QVBoxLayout()

        user = QLabel("Administrator")

        user.setStyleSheet("""
            color:white;
            font-size:14px;
            font-weight:bold;
        """)

        status = QLabel("● Connected")

        status.setStyleSheet("""
            color:#3FB950;
            font-size:12px;
        """)

        right.addWidget(user)

        right.addWidget(status)

        layout.addLayout(right)

        ##################################################

        self.setStyleSheet("""

        QFrame#TopBar{

            background:#161B22;

            border:1px solid #30363D;

            border-radius:12px;

        }

        """)

    ##########################################################

    def start_clock(self):

        self.timer = QTimer()

        self.timer.timeout.connect(
            self.update_clock
        )

        self.timer.start(1000)

        self.update_clock()

    ##########################################################

    def update_clock(self):

        now = datetime.now()

        self.time_label.setText(
            now.strftime("%H:%M:%S")
        )

        self.date_label.setText(
            now.strftime("%A, %d %B %Y")
        )